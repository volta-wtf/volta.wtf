import type { CatalogType, CatalogView } from "./lib/catalog.runtime";

export type CategoryConfig = {
  name: string;
  label: string;
  type: CatalogType;
  view: CatalogView;
  markdownGlob?: string;
  componentsGlobs?: string[];
  classesGlobs?: string[];
  variablesFiles?: string[];
  presetsGlobs?: string[];
  tags?: string[];
};

export const CATEGORIES_CONFIG: CategoryConfig[] = [
  // Docs (markdown)
  { name: "docs-guides", label: "Docs · Guides", type: "markdown", view: "doc", markdownGlob: "public/docs/guides/**/*.md" },
  { name: "docs-theme",  label: "Docs · Theme",  type: "markdown", view: "doc", markdownGlob: "public/docs/theme/**/*.md" },
  { name: "docs-ui",     label: "Docs · UI",     type: "markdown", view: "doc", markdownGlob: "public/docs/ui/**/*.md" },
  { name: "docs-app",    label: "Docs · App",    type: "markdown", view: "doc", markdownGlob: "public/docs/app/**/*.md" },

  // Components
  { name: "components-layout", label: "Components · Layout", type: "component", view: "component", componentsGlobs: ["components/previews/layout/*.tsx"] },
  { name: "components-text",   label: "Components · Text",   type: "component", view: "component", componentsGlobs: ["components/previews/text/*.tsx"] },
  { name: "components-forms",  label: "Components · Forms",  type: "component", view: "component", componentsGlobs: ["components/previews/forms/*.tsx"] },

  // Animations (if you want a dedicated canvas; otherwise merge with component)
  { name: "animations-text",        label: "Animations · Text",        type: "component", view: "animation", componentsGlobs: ["components/previews/animations/text/*.tsx"] },
  { name: "animations-collections", label: "Animations · Collections", type: "component", view: "animation", componentsGlobs: ["components/previews/animations/collections/*.tsx"] },
  { name: "animations-ui-motion",   label: "Animations · UI Motion",   type: "component", view: "animation", componentsGlobs: ["components/previews/animations/ui-motion/*.tsx"] },

  // Materials (css-classes)
  { name: "materials-content",  label: "Materials · Content",  type: "css-classes", view: "text",    classesGlobs: ["styles/materials/content/**/*.css"] },
  { name: "materials-frames",   label: "Materials · Frames",   type: "css-classes", view: "frames",  classesGlobs: ["styles/materials/frames/**/*.css"] },
  { name: "materials-forms",    label: "Materials · Forms",    type: "css-classes", view: "form",    classesGlobs: ["styles/materials/forms/**/*.css"] },

  // Styles (css-classes)
  { name: "styles-text",        label: "Styles · Text",        type: "css-classes", view: "text",       classesGlobs: ["styles/classes/text/**/*.css"] },
  { name: "styles-links",       label: "Styles · Links",       type: "css-classes", view: "text",       classesGlobs: ["styles/classes/links/**/*.css"] },
  { name: "styles-highlights",  label: "Styles · Highlights",  type: "css-classes", view: "text",       classesGlobs: ["styles/classes/highlights/**/*.css"] },
  { name: "styles-frames",      label: "Styles · Frames",      type: "css-classes", view: "frames",     classesGlobs: ["styles/classes/frames/**/*.css"] },
  { name: "styles-decorations", label: "Styles · Decorations", type: "css-classes", view: "decoration", classesGlobs: ["styles/classes/decorations/**/*.css"] },

  // Presets
  { name: "presets-shapes",    label: "Presets · Shapes",    type: "presets", view: "shape",    presetsGlobs: ["styles/presets/shapes.css"] },
  { name: "presets-borders",   label: "Presets · Borders",   type: "presets", view: "shape",    presetsGlobs: ["styles/presets/borders.css"] },
  { name: "presets-shadows",   label: "Presets · Shadows",   type: "presets", view: "shadow",   presetsGlobs: ["styles/presets/shadows.css"] },
  { name: "presets-gradients", label: "Presets · Gradients", type: "presets", view: "gradient", presetsGlobs: ["styles/presets/gradients.css"] },
  { name: "presets-images",    label: "Presets · Images",    type: "presets", view: "image",    presetsGlobs: ["styles/presets/images.css"] },

  // Variables (optional)
  { name: "variables-color", label: "Variables · Color", type: "variables", view: "color", variablesFiles: ["styles/variables/colors.css"] },
  { name: "variables-font",  label: "Variables · Font",  type: "variables", view: "font",  variablesFiles: ["styles/variables/font.css"] },
];
