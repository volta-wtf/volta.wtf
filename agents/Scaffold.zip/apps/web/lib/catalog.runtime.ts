export type CatalogType =
  | "markdown"
  | "component"
  | "css-classes"
  | "variables"
  | "presets";

export type CatalogView =
  | "doc"
  | "component"
  | "animation"
  | "text"
  | "frames"
  | "form"
  | "gradient"
  | "shape"
  | "shadow"
  | "image"
  | "decoration"
  | "color"
  | "font";

export type CatalogItem = {
  title: string;
  slug: string;
  tags?: string[];
  mdPath?: string;        // markdown
  componentName?: string; // components/animations
  cssClass?: string;      // css-classes
  variableName?: string;  // variables
  presetName?: string;    // presets
  sourceFile?: string;    // origin file (optional)
  variant?: string;       // subtype (e.g., "palette","elevation","underline")
  renderProps?: Record<string, unknown>;
};

export type Category = {
  name: string;
  label: string;
  type: CatalogType;
  view: CatalogView;
  items: CatalogItem[];
  tags?: string[];
};

// Filled by generated file
export declare const CATEGORIES: Category[];

export function getCategories(): Category[] {
  // @ts-ignore - injected by generated file
  return CATEGORIES;
}
export function getCategory(name: string) {
  return getCategories().find((c) => c.name === name);
}
export function getItem(category: string, itemSlug: string) {
  const cat = getCategory(category);
  return cat?.items.find((i) => i.slug === itemSlug);
}
